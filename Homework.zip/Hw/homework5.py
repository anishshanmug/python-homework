import math
n=int(input("How many sides does the figure have:"))
s=float(input("Enter the side length here:"))
area=(n*s*s)/(4*math.tan(3.14/n))
print(area)