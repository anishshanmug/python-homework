import math
s=float(input("Enter a number here:"))
area=(5*s*s)/(4*math.tan(3.14/5))
print(area)