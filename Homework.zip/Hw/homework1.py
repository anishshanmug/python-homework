import math
r=float(input("Enter the length from the center of the pentagon to the vertex:"))
s=2*r*math.sin(3.14/5)
Area=(3*(3**1/2)*s*s)/2
print(Area)