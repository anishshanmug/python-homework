#decorators in a local file decorators from other files multiple decorators in a file.
x=input("Enter a number four numbers with a space in between them here:")
a=x.split(" ")
a.reverse()
print(a[0],a[1],a[2],a[3])
